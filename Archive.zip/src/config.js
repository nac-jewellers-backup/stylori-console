// export const GRAPHQL_DEV_CLIENT = "http://auth-dev.ap-south-1.elasticbeanstalk.com/graphql"
// export const API_URL = "http://auth-dev.ap-south-1.elasticbeanstalk.com"

export const API_URL = "https://api.stylori.net"
export const GRAPHQL_DEV_CLIENT = "https://api.stylori.net/graphql"

// export const GRAPHQL_DEV_CLIENT = "http://localhost:8000/graphql"
// export const API_URL = "http://localhost:8000"