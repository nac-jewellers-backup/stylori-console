import React,{useState,useEffect} from 'react';
import { makeStyles } from '@material-ui/styles';
import { Grid, TextField } from '@material-ui/core';
import {Input} from '../../components/Input.js'
import { ProductContext } from '../../context';
import { withRouter } from "react-router-dom";
import DiamondDetails from './DiamondDetails';
const useStyle = makeStyles(theme=>({
    helperinput: {
        '& .MuiFormHelperText-root':{
          color: "#e53935",
        }
      }
}))

export  function ProductAttributes (probs){
    const { productCtx, setProductCtx } = React.useContext(ProductContext);
    const classes  = useStyle();
    const keyPress =type => e => {
        console.log('product',productCtx,e)
        const re = /^[a-zA-Z\b]+$/;
        if (e.target.value === '' || re.test(e.target.value)) {
          setProductCtx({ ...productCtx, [type]: e.target.value})
        }
        
     }
    return(
        <Grid container spacing={1} >
            <Grid item xs={12} sm={12} md={9} spacing={2} style={{ padding:"15px"}}>
              <Grid container item md={6}>
                    <TextField  
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          id="productname"
                          error = {productCtx.error_message.productname}
                          name="productname"
                          label="Product Name"
                          onChange={keyPress('productname')}
                        />
              </Grid>  
              <DiamondDetails />   
            </Grid>
            <Grid item  xs={12} sm={12} md={3} spacing={2} style={{ padding:"15px", backgroundColor: "#FFFFFF"}}>
            <TextField
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          InputProps={{
                            readOnly: true,
                          }}
                          id="short_description"
                          error = {productCtx.error_message.productname}
                          InputProps={{
                            readOnly: true,
                          }}
                          name="short_description"
                          label="Short Description"
                       
                        />
                       <TextField
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          id="seo_text"
                          error = {productCtx.error_message.productname}
                          InputProps={{
                            readOnly: true,
                          }}
                          name="seo_text"
                          label="SEO Text"
                       
                        />
                        <TextField
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          id="url"
                          error = {productCtx.error_message.productname}
                          InputProps={{
                            readOnly: true,
                          }}
                          name="url"
                          label="URL"
                       
                        />
                        <TextField
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          id="product_category"
                          InputProps={{
                            readOnly: true,
                          }}
                          error = {productCtx.error_message.productname}
                          name="product_category"
                          label="Product Category"
                       
                        />
                       <TextField
                          className={classes.helperinput}
                          variant="outlined"
                          margin="dense"
                          fullWidth
                          defaultValue={productCtx.productname}
                          id="product_type"
                          error = {productCtx.error_message.productname}
                          InputProps={{
                            readOnly: true,
                          }}
                          name="product_type"
                          label="Product Type"
                       
                        />
                        
            </Grid>
        </Grid>
    )
}

export default (withRouter(ProductAttributes))