export { default } from './VoucherComponent';
