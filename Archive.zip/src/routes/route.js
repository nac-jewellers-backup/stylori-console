const route = {
    login: '/login',
    dashboard: '/dashboard',
    profile: '/profile',
    productupload: '/productupload',
    configuration: '/Configuration',
    vendor: '/vendorlist',
    productlist: '/productlist',
    materiallist: '/material',
    producttypes: '/producttypes',
    voucherdiscount: '/voucherdiscount',
    priceupdate: '/priceupdate'

}

export default route;